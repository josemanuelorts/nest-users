import { Body, Controller, Get, Post } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UsersService } from './users.service';
import { Throttle } from '@nestjs/throttler';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post()
  create(@Body() body: CreateUserDto) {
    return this.usersService.create(body.name, body.email);
  }

  @Throttle({
    default: {
      limit: 5,
      ttl: 10000,
    },
  }) 
  @Get()
  findAll() {
    return this.usersService.findAll();
  }
}

