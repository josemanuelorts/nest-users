export interface StoredUser {
  id: number;
  name: string;
  email: string;
  avatar?: string;
  externalData?: any;
}
