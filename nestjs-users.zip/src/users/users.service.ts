import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import axios from 'axios';
import { StoredUser } from './interfaces/stored-user.interface';

// Interfaz clara para la data que viene de la API externa
interface ReqresUserData {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  avatar: string;
}

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);
  private users: StoredUser[] = [];

  async create(name: string, email: string): Promise<StoredUser> {
    const normalizedEmail = email.toLowerCase().trim();
    const exists = this.users.find(u => u.email.toLowerCase() === normalizedEmail);
    if (exists) {
      throw new BadRequestException('User already exists');
    }

    // Puedes implementar lógica más sofisticada para elegir externalId
    const externalId = Math.floor(Math.random() * 10) + 1;

    let externalData: ReqresUserData | null = null;
    try {
      const response = await axios.get<{ data: ReqresUserData }>(
        `https://reqres.in/api/users/${externalId}`
      );
      externalData = response.data.data;
    } catch (error: any) {
      this.logger.warn(`Error fetching external data: ${error.message || error}`);
      // Podrías decidir si quieres fallar la creación o continuar sin datos externos
    }

    const newUser: StoredUser = {
      id: this.users.length + 1,
      name,
      email: normalizedEmail,
      avatar: externalData?.avatar,
      externalData,
    };

    this.users.push(newUser);
    return newUser;
  }

  findAll(): StoredUser[] {
    return this.users;
  }
}
